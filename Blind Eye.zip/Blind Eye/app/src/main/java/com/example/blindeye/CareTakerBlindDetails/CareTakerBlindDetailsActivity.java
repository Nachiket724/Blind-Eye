package com.example.blindeye.CareTakerBlindDetails;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import com.example.blindeye.R;

public class CareTakerBlindDetailsActivity extends AppCompatActivity {

    private Button yourDetailsButton, blindPersonDetailsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_care_taker_blind_details);

        yourDetailsButton=findViewById(R.id.yourDetailsButton);
        blindPersonDetailsButton=findViewById(R.id.blindDetailsButton);

        yourDetailsButton.setTranslationX(-800);
        blindPersonDetailsButton.setTranslationX(800);

        yourDetailsButton.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(400).start();
        blindPersonDetailsButton.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(400).start();

        yourDetailsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),CaretakerDetailsActivity.class);
                startActivity(intent);
            }
        });

        blindPersonDetailsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),BlindPersonDetailsActivity.class);
                startActivity(intent);
            }
        });
    }
}