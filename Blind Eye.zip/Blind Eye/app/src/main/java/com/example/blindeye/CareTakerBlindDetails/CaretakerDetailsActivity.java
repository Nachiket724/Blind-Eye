package com.example.blindeye.CareTakerBlindDetails;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.blindeye.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class CaretakerDetailsActivity extends AppCompatActivity {

    private TextView userNameTextView, phoneNumberTextView, emailTextView, genderTextView, birthdayTextView;
    private ImageView careTakerImageView;
    private CardView careTakerCardView;

    private StorageReference storageReference;
    private FirebaseUser firebaseUser;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_caretaker_details);

        userNameTextView=findViewById(R.id.userNameTextView);
        phoneNumberTextView=findViewById(R.id.phoneNumberTextView);
        emailTextView=findViewById(R.id.emailTextView);
        genderTextView=findViewById(R.id.genderTextView);
        birthdayTextView=findViewById(R.id.birthdateTextView);
        careTakerImageView=findViewById(R.id.careTakerImageView);
        careTakerCardView=findViewById(R.id.careTakerCardView);

        LocationManager manager = (LocationManager) getSystemService( Context.LOCATION_SERVICE );

        if ( !manager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
            buildAlertMessageNoGps();
        }



        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        databaseReference= FirebaseDatabase.getInstance().getReference("MyUsers");


        careTakerCardView.setTranslationX(800);
        careTakerImageView.setTranslationX(800);
        userNameTextView.setTranslationX(800);
        phoneNumberTextView.setTranslationX(800);
        emailTextView.setTranslationX(800);
        genderTextView.setTranslationX(800);
        birthdayTextView.setTranslationX(800);

        getImage();

        careTakerCardView.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        careTakerImageView.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        userNameTextView.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        phoneNumberTextView.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        emailTextView.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        genderTextView.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        birthdayTextView.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String userName="Name: "+snapshot.child(firebaseUser.getUid()).child("mFullName").getValue(String.class);
                String mobileNumber="Mobile No.: "+snapshot.child(firebaseUser.getUid()).child("mPhone").getValue(String.class);
                String email="Email ID: "+snapshot.child(firebaseUser.getUid()).child("mEmail").getValue(String.class);
                String gender=snapshot.child(firebaseUser.getUid()).child("gender").getValue(String.class);
                String birthdate="Birthdate: "+snapshot.child(firebaseUser.getUid()).child("date").getValue(String.class);

                if(gender.equals("Male"))
                {
                    Drawable img = getApplicationContext().getResources().getDrawable(R.drawable.ic_male_black);
                    genderTextView.setCompoundDrawablesWithIntrinsicBounds(img, null, null, null);
                }
                else
                {
                    Drawable img = getApplicationContext().getResources().getDrawable(R.drawable.ic_female_black);
                    genderTextView.setCompoundDrawablesWithIntrinsicBounds(img, null, null, null);
                }

                userNameTextView.setText(userName);
                phoneNumberTextView.setText(mobileNumber);
                emailTextView.setText(email);
                genderTextView.setText("Gender: "+gender);
                birthdayTextView.setText(birthdate);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Your GPS seems to be disabled, you want to enable it!!")
                .setCancelable(false)
                .setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }
    private void getImage()
    {
        storageReference= FirebaseStorage.getInstance().getReference();

        final StorageReference image = storageReference.child(firebaseUser.getUid()).child("caretaker.jpg");

        image.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri).into(careTakerImageView);
            }
        });
    }
}