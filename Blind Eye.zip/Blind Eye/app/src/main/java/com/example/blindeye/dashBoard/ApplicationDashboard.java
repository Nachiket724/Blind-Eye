package com.example.blindeye.dashBoard;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.example.blindeye.CareTakerBlindDetails.CareTakerBlindDetailsActivity;
import com.example.blindeye.Logout.BothLogoutActivity;
import com.example.blindeye.MapsActivity.MapsAllData;
import com.example.blindeye.MapsActivity.ModesNavigationActivity;
import com.example.blindeye.R;
import com.example.blindeye.loginSignup.Register;
import com.example.blindeye.welcomeScreen.SignInOrSignUp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ApplicationDashboard extends AppCompatActivity {

    private ImageView blindPersonLocationImageView, navigationSystemImageView, userDetailsImageView, logoutImageView;
    private TextView blindPersonLocationTextView, navigationSystemTextView, userDetailsTextView, logoutTextView;
    private CardView blindPersonLocationCardView, navigationSystemCardView, userDetailsCardView, logoutCardView;

    private FirebaseUser firebaseUser;
    private DatabaseReference databaseReference;
    private boolean newUser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_application_dashboard);

        blindPersonLocationImageView=findViewById(R.id.blindPersonLocationImageView);
        navigationSystemImageView=findViewById(R.id.navigationSystemImageView);
        userDetailsImageView=findViewById(R.id.userDetailsImageView);
        logoutImageView=findViewById(R.id.logoutImageView);

        blindPersonLocationCardView=findViewById(R.id.blindPersonLocationCardView);
        navigationSystemCardView=findViewById(R.id.navigationSystemCardView);
        userDetailsCardView=findViewById(R.id.userDetailsCardView);
        logoutCardView=findViewById(R.id.logoutCardView);

        blindPersonLocationTextView=findViewById(R.id.blindPersonLocationTextView);
        navigationSystemTextView=findViewById(R.id.navigationSystemTextView);
        userDetailsTextView=findViewById(R.id.userDetailsTextView);
        logoutTextView=findViewById(R.id.logoutTextView);

        final LocationManager manager = (LocationManager) getSystemService( Context.LOCATION_SERVICE );

        if ( !manager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
            buildAlertMessageNoGps();
        }

        if(ContextCompat.checkSelfPermission(ApplicationDashboard.this,
                Manifest.permission.CAMERA)+
                ContextCompat.checkSelfPermission(ApplicationDashboard.this,
                        Manifest.permission.ACCESS_FINE_LOCATION)+
                ContextCompat.checkSelfPermission(ApplicationDashboard.this,
                        Manifest.permission.ACCESS_COARSE_LOCATION)+
                ContextCompat.checkSelfPermission(ApplicationDashboard.this,
                        Manifest.permission.READ_EXTERNAL_STORAGE)+
                ContextCompat.checkSelfPermission(ApplicationDashboard.this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)+
                ContextCompat.checkSelfPermission(ApplicationDashboard.this,
                        Manifest.permission.CALL_PHONE)+
                ContextCompat.checkSelfPermission(ApplicationDashboard.this,
                        Manifest.permission.INTERNET)+
                ContextCompat.checkSelfPermission(ApplicationDashboard.this,
                        Manifest.permission.RECORD_AUDIO)!=
                PackageManager.PERMISSION_GRANTED)
        {
            Intent intent=new Intent();
            intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            Uri uri=Uri.fromParts("package",getPackageName(),null);
            intent.setData(uri);
            startActivity(intent);
        }

        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();

        databaseReference= FirebaseDatabase.getInstance().getReference("MyUsers");

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                newUser=snapshot.child(firebaseUser.getUid()).child("Blind").child("newLogin").getValue(Boolean.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        blindPersonLocationCardView.setTranslationX(-800);
        blindPersonLocationImageView.setTranslationX(-800);
        blindPersonLocationTextView.setTranslationX(-800);

        navigationSystemCardView.setTranslationX(800);
        navigationSystemImageView.setTranslationX(800);
        navigationSystemTextView.setTranslationX(800);

        userDetailsCardView.setTranslationX(-800);
        userDetailsImageView.setTranslationX(-800);
        userDetailsTextView.setTranslationX(-800);

        logoutCardView.setTranslationX(800);
        logoutImageView.setTranslationX(800);
        logoutTextView.setTranslationX(800);

        blindPersonLocationCardView.animate().translationX(0).alpha(1).setDuration(1000).setStartDelay(700).start();
        blindPersonLocationImageView.animate().translationX(0).alpha(1).setDuration(1000).setStartDelay(700).start();
        blindPersonLocationTextView.animate().translationX(0).alpha(1).setDuration(1000).setStartDelay(700).start();

        navigationSystemCardView.animate().translationX(0).alpha(1).setDuration(1000).setStartDelay(700).start();
        navigationSystemImageView.animate().translationX(0).alpha(1).setDuration(1000).setStartDelay(700).start();
        navigationSystemTextView.animate().translationX(0).alpha(1).setDuration(1000).setStartDelay(700).start();

        userDetailsCardView.animate().translationX(0).alpha(1).setDuration(1000).setStartDelay(700).start();
        userDetailsImageView.animate().translationX(0).alpha(1).setDuration(1000).setStartDelay(700).start();
        userDetailsTextView.animate().translationX(0).alpha(1).setDuration(1000).setStartDelay(700).start();

        logoutCardView.animate().translationX(0).alpha(1).setDuration(1000).setStartDelay(700).start();
        logoutImageView.animate().translationX(0).alpha(1).setDuration(1000).setStartDelay(700).start();
        logoutTextView.animate().translationX(0).alpha(1).setDuration(1000).setStartDelay(700).start();

        blindPersonLocationCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mapsAllDataActivity();
            }
        });

        blindPersonLocationImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mapsAllDataActivity();
            }
        });

        blindPersonLocationTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mapsAllDataActivity();
            }
        });

        navigationSystemCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigationSystemActivity();
            }
        });

        navigationSystemImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigationSystemActivity();
            }
        });

        navigationSystemTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigationSystemActivity();
            }
        });

        userDetailsCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userDetailsActivity();
            }
        });

        userDetailsImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userDetailsActivity();
            }
        });

        userDetailsTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userDetailsActivity();
            }
        });

        logoutCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutActivity();
            }
        });

        logoutImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutActivity();
            }
        });

        logoutTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutActivity();
            }
        });
    }

    private void mapsAllDataActivity()
    {
        Intent intent=new Intent(getApplicationContext(), MapsAllData.class);
        startActivity(intent);
    }

    private void navigationSystemActivity()
    {
        if(newUser)
        {
            Toast.makeText(this, "Please Login into the Blind Person Application to start Navigation", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Intent intent=new Intent(getApplicationContext(), ModesNavigationActivity.class);
            startActivity(intent);
        }
    }

    private void userDetailsActivity()
    {
        Intent intent=new Intent(getApplicationContext(), CareTakerBlindDetailsActivity.class);
        startActivity(intent);
    }

    private void logoutActivity()
    {
        Intent intent=new Intent(getApplicationContext(), BothLogoutActivity.class);
        startActivity(intent);
        finish();
    }

    private void buildAlertMessageNoGps() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Your GPS seems to be disabled, you have to enable it!!")
                .setCancelable(false)
                .setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);

        builder.setMessage("Do you want to close this Application?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                        System.exit(0);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();
    }
}