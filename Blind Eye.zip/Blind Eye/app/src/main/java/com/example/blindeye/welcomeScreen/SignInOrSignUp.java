package com.example.blindeye.welcomeScreen;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.example.blindeye.R;
import com.example.blindeye.dashBoard.ApplicationDashboard;
import com.example.blindeye.loginSignup.Login;
import com.example.blindeye.loginSignup.Register;
import com.google.firebase.auth.FirebaseAuth;

public class SignInOrSignUp extends AppCompatActivity {

    FirebaseAuth fAuth;

    private Button towardsLoginPage,towardsRegisterPage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_sign_in_or_sign_up);

        fAuth=FirebaseAuth.getInstance();

        if(fAuth.getCurrentUser()!=null)
        {
            startActivity(new Intent(getApplicationContext(), ApplicationDashboard.class));
            finish();
        }

        towardsLoginPage=findViewById(R.id.towardsLoginPage);
        towardsRegisterPage=findViewById(R.id.towardsRegisterPage);

        towardsLoginPage.setTranslationX(-800);
        towardsRegisterPage.setTranslationX(800);

        towardsLoginPage.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(400).start();
        towardsRegisterPage.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(400).start();

        towardsLoginPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(), Login.class);
                startActivity(intent);
                Animatoo.animateFade(SignInOrSignUp.this);
                finish();
            }
        });

        towardsRegisterPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(), Register.class);
                startActivity(intent);
                Animatoo.animateFade(SignInOrSignUp.this);
                finish();
            }
        });
    }
    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setMessage("Are you sure, you want to Exit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                        System.exit(0);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();
    }
}