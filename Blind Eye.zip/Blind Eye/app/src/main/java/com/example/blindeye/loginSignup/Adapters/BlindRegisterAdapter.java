package com.example.blindeye.loginSignup.Adapters;

public class BlindRegisterAdapter {

    private String blindName;
    private String blindPhone;
    private String gender;
    private String dob;
    private boolean logout;
    private boolean newLogin;

    public BlindRegisterAdapter() {
    }

    public BlindRegisterAdapter(String blindName, String blindPhone, String gender, String dob, boolean logout,boolean newLogin) {
        this.blindName = blindName;
        this.blindPhone = blindPhone;
        this.gender = gender;
        this.dob = dob;
        this.logout=logout;
        this.newLogin=newLogin;
    }

    public String getBlindName() {
        return blindName;
    }

    public void setBlindName(String blindName) {
        this.blindName = blindName;
    }

    public String getBlindPhone() {
        return blindPhone;
    }

    public void setBlindPhone(String blindPhone) {
        this.blindPhone = blindPhone;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public boolean isLogout() {
        return logout;
    }

    public void setLogout(boolean logout) {
        this.logout = logout;
    }

    public boolean isNewLogin() {
        return newLogin;
    }

    public void setNewLogin(boolean newLogin) {
        this.newLogin = newLogin;
    }
}
