package com.example.blindeye.loginSignup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatRadioButton;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.agrawalsuneet.dotsloader.loaders.CircularDotsLoader;
import com.blogspot.atifsoftwares.animatoolib.Animatoo;


import com.example.blindeye.R;
import com.example.blindeye.dashBoard.ApplicationDashboard;
import com.example.blindeye.loginSignup.Adapters.BlindRegisterAdapter;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BlindRegistrationPart extends AppCompatActivity {

    private String gender;

    Intent intent;
    StorageReference storageReference;

    private String blindName;
    private String blindPhone;
    private boolean logout=false;
    private boolean newLogin=true;

    private int mDate,mMonth,mYear;

    private TextView mDisplayBirthdate;
    private TextView mBlindName;
    ImageView blindImageView,logoRegister,backgroundImage;

    private TextView mBlindPhone;
    private Button proceedNext;

    Uri imageUri;
    String currentPhotoPath;

    AppCompatRadioButton radio_male,radio_female;
    RadioGroup radioGroup;
    RadioButton radioButton;

    ConstraintLayout constraintLayoutBlind,constraintLayoutRadioGroupsBlind;

    FirebaseUser firebaseUser;
    DatabaseReference databaseReference;

    CircularDotsLoader progressBarBlind;

    static final int REQUEST_CODE=123;

    private final String regexPhoneNo="^[6-9]\\d{9}$";
    private final String regexName="^[A-Za-z][a-zA-Z ]+$";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_blind_registration);

        final LocationManager manager = (LocationManager) getSystemService( Context.LOCATION_SERVICE );

        if ( !manager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
            buildAlertMessageNoGps();
        }

        if(ContextCompat.checkSelfPermission(BlindRegistrationPart.this,
                Manifest.permission.CAMERA)+
                ContextCompat.checkSelfPermission(BlindRegistrationPart.this,
                        Manifest.permission.ACCESS_FINE_LOCATION)+
                ContextCompat.checkSelfPermission(BlindRegistrationPart.this,
                        Manifest.permission.ACCESS_COARSE_LOCATION)+
                ContextCompat.checkSelfPermission(BlindRegistrationPart.this,
                        Manifest.permission.READ_EXTERNAL_STORAGE)+
                ContextCompat.checkSelfPermission(BlindRegistrationPart.this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)+
                ContextCompat.checkSelfPermission(BlindRegistrationPart.this,
                        Manifest.permission.CALL_PHONE)+
                ContextCompat.checkSelfPermission(BlindRegistrationPart.this,
                        Manifest.permission.INTERNET)+
                ContextCompat.checkSelfPermission(BlindRegistrationPart.this,
                        Manifest.permission.RECORD_AUDIO)!=
                PackageManager.PERMISSION_GRANTED)
        {
            Intent intent=new Intent();
            intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            Uri uri=Uri.fromParts("package",getPackageName(),null);
            intent.setData(uri);
            startActivity(intent);
        }

        constraintLayoutBlind=findViewById(R.id.constraintlayoutBlind);
        mDisplayBirthdate=findViewById(R.id.birthdayBlindNew);
        radioGroup=findViewById(R.id.radioGroupBlindNew);
        proceedNext=findViewById(R.id.blindCompleteBtnNew);
        mBlindName=findViewById(R.id.editTextBlindNameNew);
        mBlindPhone=findViewById(R.id.editTextBlindPhoneNew);
        progressBarBlind=findViewById(R.id.progressBarBlind);
        blindImageView=findViewById(R.id.blindImageView);
        constraintLayoutRadioGroupsBlind=findViewById(R.id.constraintLayoutRadioGroupsBlind);
        radio_male=findViewById(R.id.maleRadioBlindNew);
        radio_female=findViewById(R.id.femaleRadioBlindNew);
        logoRegister=findViewById(R.id.logoRegister);
        //registerText=findViewById(R.id.registerText);
        backgroundImage=findViewById(R.id.backgroundImage);

        constraintLayoutBlind.setVisibility(View.VISIBLE);

        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();

        databaseReference= FirebaseDatabase.getInstance().getReference("MyUsers");

        storageReference= FirebaseStorage.getInstance().getReference();

        mBlindPhone.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                return false;
            }
        });
        mBlindName.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                return false;
            }
        });
        mDisplayBirthdate.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                return false;
            }
        });


        mBlindName.setTranslationX(800);
        mBlindPhone.setTranslationX(800);
        mDisplayBirthdate.setTranslationX(800);
        constraintLayoutRadioGroupsBlind.setTranslationX(800);
        proceedNext.setTranslationX(800);

        mBlindName.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        mBlindPhone.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(700).start();
        mDisplayBirthdate.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(900).start();
        constraintLayoutRadioGroupsBlind.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(1100).start();
        proceedNext.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(1300).start();

        CircularDotsLoader loader = new CircularDotsLoader(this);
        loader.setBigCircleRadius(80);
        loader.setRadius(24);
        loader.setAnimDur(300);
        loader.setShowRunningShadow(true);

        logoRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickedBackground();
            }
        });

//        registerText.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                clickedBackground();
//            }
//        });
        backgroundImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickedBackground();
            }
        });

        blindImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder=new AlertDialog.Builder(BlindRegistrationPart.this);
                builder.setTitle("Add Profile Photo!!");
                builder.setPositiveButton("Camera", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        askCameraPermission();
                    }
                });
                builder.setNegativeButton("Gallery", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent openGalleryIntent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        startActivityForResult(openGalleryIntent,1000);
                    }
                });
                AlertDialog alertDialog=builder.create();
                alertDialog.show();
            }
        });

        mDisplayBirthdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar calendar = Calendar.getInstance();

                mDate=calendar.get(Calendar.DATE);
                mMonth=calendar.get(Calendar.MONTH);
                mYear=calendar.get(Calendar.YEAR);

                DatePickerDialog datePickerDialog=new DatePickerDialog(BlindRegistrationPart.this, android.R.style.Theme_DeviceDefault_Dialog, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int date) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.set(year, month, date);
                        SimpleDateFormat format = new SimpleDateFormat("dd MMMM yyyy");
                        String dateString = format.format(calendar.getTime());
                        mDisplayBirthdate.setText(dateString);
                    }
                },mYear,mMonth,mDate);
                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis()-1000);
                datePickerDialog.show();
            }
        });

        proceedNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int radioId=radioGroup.getCheckedRadioButtonId();

                radioButton=findViewById(radioId);
                gender=radioButton.getText().toString();
                blindName=mBlindName.getText().toString();
                blindPhone=mBlindPhone.getText().toString();
                String bDate=mDisplayBirthdate.getText().toString();

                if(TextUtils.isEmpty(blindName))
                {
                    mBlindName.setError("Name is Required !");
                    return;
                }
                if(TextUtils.isEmpty(blindPhone))
                {
                    mBlindPhone.setError("Phone Number is Required !");
                    return;
                }

                if(bDate==null || bDate.isEmpty() || TextUtils.isEmpty(bDate))
                {
                    mDisplayBirthdate.setError("Select Birthdate");
                    return;
                }

                if(imageUri==null)
                {
                    AlertDialog.Builder builder=new AlertDialog.Builder(BlindRegistrationPart.this);
                    builder.setTitle("Upload Profile Photo!!");
                    builder.setPositiveButton("Okay",null);
                    AlertDialog alertDialog=builder.create();
                    alertDialog.show();
                    return;
                }

                Pattern patternName = Pattern.compile(regexName);
                Matcher matcherName=patternName.matcher(blindName);

                Pattern patternPhone=Pattern.compile(regexPhoneNo);
                Matcher matcherPhone=patternPhone.matcher(blindPhone);

                if(!matcherName.matches())
                {
                    mBlindName.setError("Name must contain more than one Alphabets !");
                    return;
                }
                if(!matcherPhone.matches())
                {
                    mBlindPhone.setError("Enter Valid 10 Digit Mobile Number");
                    return;
                }

                progressBarBlind.setVisibility(View.VISIBLE);

                BlindRegisterAdapter blindRegisterAdapter=new BlindRegisterAdapter(blindName,blindPhone,gender,bDate,logout,newLogin);

                databaseReference.child(firebaseUser.getUid()).child("Blind").setValue(blindRegisterAdapter);

                uploadImageToFirebase(imageUri );

                intent=new Intent(getApplicationContext(), ApplicationDashboard.class);
                startActivity(intent);
                Animatoo.animateSwipeLeft(BlindRegistrationPart.this);
                finish();
            }
        });
    }

    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Your GPS seems to be disabled, you want to enable it!!")
                .setCancelable(false)
                .setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    private void askCameraPermission() {
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},101);
        }
        else
        {
            dispatchTakePictureIntent();
        }
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String imageFileName = "blind";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                imageUri = FileProvider.getUriForFile(this,
                        "com.example.android.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                startActivityForResult(takePictureIntent, 102);
            }
        }
    }

    private void uploadImageToFirebase(Uri imageUri ) {

        StorageReference fileRef=storageReference.child(firebaseUser.getUid()).child("blind.jpg");
        fileRef.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(BlindRegistrationPart.this, "Failed!!", Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==1000)
        {
            if(resultCode== Activity.RESULT_OK)
            {
                imageUri = data.getData();
                blindImageView.setImageURI(imageUri);
            }
        }
        else if(requestCode==102)
        {
            if(resultCode==Activity.RESULT_OK)
            {
                File f=new File(currentPhotoPath);
                blindImageView.setImageURI(Uri.fromFile(f));
            }
        }
    }

    public void onRadioButtonClicked(View view)
    {
        boolean isSelected=((AppCompatRadioButton)view).isChecked();

        switch (view.getId())
        {
            case R.id.maleRadioBlindNew:

                if(isSelected) {
                    radio_male.setTextColor(Color.WHITE);
                    radio_female.setTextColor(Color.parseColor("#306e70"));
                }
                break;
            case R.id.femaleRadioBlindNew:
                if(isSelected) {
                    radio_male.setTextColor(Color.parseColor("#306e70"));
                    radio_female.setTextColor(Color.WHITE);
                }
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode==101)
        {
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
            {
                dispatchTakePictureIntent();
            }
            else
            {
                Toast.makeText(this, "Camera Permission is Required!!", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private void clickedBackground()
    {
        try {
            InputMethodManager inputMethodManager=(InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),0);
        }catch (Exception e)
        {

        }

    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);

        builder.setMessage("You cannot exit the Application, untill you complete the Registration Part !! ")
                .setCancelable(false)
                .setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();
    }

}