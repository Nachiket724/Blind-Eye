package com.example.blindeye.welcomeScreen;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.example.blindeye.R;
import com.example.blindeye.loginSignup.Register;

public class PermissionActivity extends AppCompatActivity {

    Button btnCheck,btnRequest;

    static final int REQUEST_CODE=123;

    MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_permission);

        btnCheck=findViewById(R.id.bt_check);
        btnRequest=findViewById(R.id.bt_request);

        if(mediaPlayer==null)
        {
            mediaPlayer=MediaPlayer.create(this,R.raw.pleaseallowpermission);
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    stopPlayer();
                }
            });

        }

        btnRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ContextCompat.checkSelfPermission(PermissionActivity.this,
                        Manifest.permission.CAMERA)+
                        ContextCompat.checkSelfPermission(PermissionActivity.this,
                                Manifest.permission.ACCESS_FINE_LOCATION)+
                        ContextCompat.checkSelfPermission(PermissionActivity.this,
                                Manifest.permission.ACCESS_COARSE_LOCATION)+
                        ContextCompat.checkSelfPermission(PermissionActivity.this,
                                Manifest.permission.READ_EXTERNAL_STORAGE)+
                        ContextCompat.checkSelfPermission(PermissionActivity.this,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE)+
                        ContextCompat.checkSelfPermission(PermissionActivity.this,
                                Manifest.permission.CALL_PHONE)+
                        ContextCompat.checkSelfPermission(PermissionActivity.this,
                                Manifest.permission.INTERNET)+
                        ContextCompat.checkSelfPermission(PermissionActivity.this,
                                Manifest.permission.RECORD_AUDIO)!=
                        PackageManager.PERMISSION_GRANTED)
                {
                    if(ActivityCompat.shouldShowRequestPermissionRationale(PermissionActivity.this,
                            Manifest.permission.CAMERA) || ActivityCompat.shouldShowRequestPermissionRationale(
                            PermissionActivity.this,Manifest.permission.ACCESS_FINE_LOCATION)||
                            ActivityCompat.shouldShowRequestPermissionRationale(PermissionActivity.this,
                                    Manifest.permission.ACCESS_COARSE_LOCATION)||
                            ActivityCompat.shouldShowRequestPermissionRationale(PermissionActivity.this,
                                    Manifest.permission.READ_EXTERNAL_STORAGE)||
                            ActivityCompat.shouldShowRequestPermissionRationale(PermissionActivity.this,
                                    Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                            ActivityCompat.shouldShowRequestPermissionRationale(PermissionActivity.this,
                                    Manifest.permission.CALL_PHONE)||
                            ActivityCompat.shouldShowRequestPermissionRationale(PermissionActivity.this,
                                    Manifest.permission.INTERNET)||
                            ActivityCompat.shouldShowRequestPermissionRationale(PermissionActivity.this,
                                    Manifest.permission.RECORD_AUDIO)
                    )
                    {
                        AlertDialog.Builder builder=new AlertDialog.Builder(PermissionActivity.this);
                        builder.setTitle("Grant Permissions");
                        builder.setMessage("Camera, Location, Storage, Call, Audio and Internet Permission Needed in order to use this Application");
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ActivityCompat.requestPermissions(
                                        PermissionActivity.this,
                                        new String[]{
                                                Manifest.permission.CAMERA,
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION,
                                                Manifest.permission.READ_EXTERNAL_STORAGE,
                                                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                                Manifest.permission.CALL_PHONE,
                                                Manifest.permission.INTERNET,
                                                Manifest.permission.RECORD_AUDIO
                                        },REQUEST_CODE
                                );
                            }
                        });
                        builder.setNegativeButton("Cancel",null);
                        AlertDialog alertDialog=builder.create();
                        alertDialog.show();
                    }
                    else
                    {
                        ActivityCompat.requestPermissions(
                                PermissionActivity.this,
                                new String[]{
                                        Manifest.permission.CAMERA,
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION,
                                        Manifest.permission.READ_EXTERNAL_STORAGE,
                                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                        Manifest.permission.CALL_PHONE,
                                        Manifest.permission.INTERNET,
                                        Manifest.permission.RECORD_AUDIO
                                },REQUEST_CODE
                        );
                    }
                }
                else
                {
                    //Toast.makeText(PermissionActivity.this, "Permission ALready Granted", Toast.LENGTH_SHORT).show();
                    stopPlayer();
                    Intent intent=new Intent(getApplicationContext(), SignInOrSignUp.class);
                    startActivity(intent);
                    finish();
                }
            }
        });

        btnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri=Uri.fromParts("package",getPackageName(),null);
                intent.setData(uri);
                startActivity(intent);
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode==REQUEST_CODE)
        {
            if((grantResults.length>0) && grantResults[0]+grantResults[1]+grantResults[2]+grantResults[3]+
                    grantResults[4]+grantResults[5]+grantResults[6]+grantResults[7]==PackageManager.PERMISSION_GRANTED)
            {
                Intent intent=new Intent(getApplicationContext(), SignInOrSignUp.class);
                stopPlayer();
                startActivity(intent);
                finish();
            }
            else
            {
                Toast.makeText(this, "All Permission are required !!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void stopPlayer()
    {
        if(mediaPlayer!=null)
        {
            mediaPlayer.release();
            mediaPlayer=null;
        }
    }
    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setMessage("Are you sure, you want to Exit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                        System.exit(0);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();
    }
}