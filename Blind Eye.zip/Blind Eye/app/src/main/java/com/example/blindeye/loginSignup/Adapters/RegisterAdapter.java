package com.example.blindeye.loginSignup.Adapters;

public class RegisterAdapter {

    private String mFullName;
    private String mEmail;
    private String mPhone;
    private String mfirebaseUserId;
    private String mdate;
    private String mgender;

    public RegisterAdapter() {
    }

    public RegisterAdapter(String mFullName, String mEmail, String mPhone, String firebaseUserId, String date, String gender) {
        this.mFullName = mFullName;
        this.mEmail = mEmail;
        this.mPhone = mPhone;
        this.mfirebaseUserId = firebaseUserId;
        this.mdate = date;
        this.mgender = gender;
    }

    public String getmFullName() {
        return mFullName;
    }

    public void setmFullName(String mFullName) {
        this.mFullName = mFullName;
    }

    public String getmEmail() {
        return mEmail;
    }

    public void setmEmail(String mEmail) {
        this.mEmail = mEmail;
    }

    public String getmPhone() {
        return mPhone;
    }

    public void setmPhone(String mPhone) {
        this.mPhone = mPhone;
    }

    public String getFirebaseUserId() {
        return mfirebaseUserId;
    }

    public void setFirebaseUserId(String firebaseUserId) {
        this.mfirebaseUserId = firebaseUserId;
    }

    public String getDate() {
        return mdate;
    }

    public void setDate(String date) {
        this.mdate = date;
    }

    public String getGender() {
        return mgender;
    }

    public void setGender(String gender) {
        this.mgender = gender;
    }
}
