package com.example.blindeye.MapsActivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import com.example.blindeye.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ModesNavigationActivity extends AppCompatActivity {

    private Button drivingMode,bicyclingMode,twoWheelerMode,walkingMode;
    private FirebaseUser firebaseUser;
    private DatabaseReference databaseReference;
    private double latitude;
    private double longitude;
    String mode="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_modes_navigation);

        drivingMode=findViewById(R.id.drivingModeNavigation);
        bicyclingMode=findViewById(R.id.bicyclingModeNavigation);
        twoWheelerMode=findViewById(R.id.twoWheelerModeNavigation);
        walkingMode=findViewById(R.id.walkingModeNavigation);

        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();

        databaseReference= FirebaseDatabase.getInstance().getReference("MyUsers");

        drivingMode.setTranslationX(800);
        bicyclingMode.setTranslationX(-800);
        twoWheelerMode.setTranslationX(800);
        walkingMode.setTranslationX(-800);

        drivingMode.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(400).start();
        bicyclingMode.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(400).start();
        twoWheelerMode.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(400).start();
        walkingMode.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(400).start();

        drivingMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mode="d";
                startNavigation();
            }
        });

        bicyclingMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mode="b";
                startNavigation();
            }
        });

        twoWheelerMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mode="l";
                startNavigation();
            }
        });

        walkingMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mode="w";
                startNavigation();
            }
        });

    }
    private void startNavigation()
    {
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                latitude=snapshot.child(firebaseUser.getUid()).child("Location").child("location").child("latitude").getValue(Double.class);
                longitude=snapshot.child(firebaseUser.getUid()).child("Location").child("location").child("longitude").getValue(Double.class);
                Intent intent=new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q="+latitude+","+longitude+"&mode="+mode));
                intent.setClassName("com.google.android.apps.maps", "com.google.android.maps.MapsActivity");
                if(intent.resolveActivity(getPackageManager())!=null)
                {
                    Log.i("Inside:  ","Modes");
                    startActivity(intent);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

}