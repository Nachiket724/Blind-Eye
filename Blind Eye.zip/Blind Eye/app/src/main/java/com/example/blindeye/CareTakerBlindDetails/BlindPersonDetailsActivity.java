package com.example.blindeye.CareTakerBlindDetails;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.blindeye.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class BlindPersonDetailsActivity extends AppCompatActivity {

    private TextView blindNameTextView, blindPhoneNumberTextView, blindGenderTextView, blindBirthdayTextView, blindBatteryTextView,lowBatteryIndicatorTextView;
    private ImageView blindImageView;
    private CardView blindCardView;
    private Button callBlindPerson;

    private StorageReference storageReference;
    private FirebaseUser firebaseUser;
    private DatabaseReference databaseReference;
    private boolean callBlind=false;
    private String phoneNumber="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_blind_person_details);

        blindNameTextView=findViewById(R.id.blindNameTextView);
        blindPhoneNumberTextView=findViewById(R.id.blindPhoneNumberTextView);
        blindGenderTextView=findViewById(R.id.blindGenderTextView);
        blindBirthdayTextView=findViewById(R.id.blindBirthdateTextView);
        blindBatteryTextView=findViewById(R.id.blindBatteryTextView);
        blindImageView=findViewById(R.id.blindImageView);
        blindCardView=findViewById(R.id.blindCardView);
        callBlindPerson=findViewById(R.id.callBlindPerson);
        lowBatteryIndicatorTextView=findViewById(R.id.lowBatteryTextView);

        LocationManager manager = (LocationManager) getSystemService( Context.LOCATION_SERVICE );

        if ( !manager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
            buildAlertMessageNoGps();
        }

        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        databaseReference= FirebaseDatabase.getInstance().getReference("MyUsers");

        blindNameTextView.setTranslationX(800);
        blindPhoneNumberTextView.setTranslationX(800);
        blindGenderTextView.setTranslationX(800);
        blindBirthdayTextView.setTranslationX(800);
        blindBatteryTextView.setTranslationX(800);
        blindImageView.setTranslationX(800);
        blindCardView.setTranslationX(800);
        callBlindPerson.setTranslationX(800);

        getImage();

        blindNameTextView.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        blindPhoneNumberTextView.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        blindGenderTextView.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        blindBirthdayTextView.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        blindBatteryTextView.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        blindImageView.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        blindCardView.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        callBlindPerson.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String blindName="Name: "+snapshot.child(firebaseUser.getUid()).child("Blind").child("blindName").getValue(String.class);
                phoneNumber=snapshot.child(firebaseUser.getUid()).child("Blind").child("blindPhone").getValue(String.class);
                String gender=snapshot.child(firebaseUser.getUid()).child("Blind").child("gender").getValue(String.class);
                String birthdate="Birthdate: "+snapshot.child(firebaseUser.getUid()).child("Blind").child("dob").getValue(String.class);
                try {
                    Integer battery=snapshot.child(firebaseUser.getUid()).child("Blind").child("Battery").getValue(Integer.class);
                    if(battery<=30)
                    {
                        lowBatteryIndicatorTextView.setVisibility(View.VISIBLE);
                    }
                    if(battery>=31)
                    {
                        lowBatteryIndicatorTextView.setVisibility(View.INVISIBLE);
                    }

                    blindBatteryTextView.setText("Battery: "+battery+"%");
                }catch (NullPointerException e)
                {
                    blindBatteryTextView.setText("Please Login to know Battery Status");
                }
                callBlind=true;

                if(gender.equals("Male"))
                {
                    Drawable img = getApplicationContext().getResources().getDrawable(R.drawable.ic_male_black);
                    blindGenderTextView.setCompoundDrawablesWithIntrinsicBounds(img, null, null, null);
                }
                else
                {
                    Drawable img = getApplicationContext().getResources().getDrawable(R.drawable.ic_female_black);
                    blindGenderTextView.setCompoundDrawablesWithIntrinsicBounds(img, null, null, null);
                }

                blindNameTextView.setText(blindName);
                blindPhoneNumberTextView.setText("Mobile No.: "+phoneNumber);
                blindGenderTextView.setText("Gender: "+gender);
                blindBirthdayTextView.setText(birthdate);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        callBlindPerson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(callBlind && phoneNumber!=null)
                {
                    Intent intentCall=new Intent(Intent.ACTION_CALL);

                    intentCall.setData(Uri.parse("tel:"+phoneNumber));

                    if(ActivityCompat.checkSelfPermission(BlindPersonDetailsActivity.this, Manifest.permission.CALL_PHONE)!=
                            PackageManager.PERMISSION_GRANTED)
                    {
                        Toast.makeText(getApplicationContext(), "Please Grant Permission", Toast.LENGTH_SHORT).show();
                        requestPermission();
                    }
                    else {
                        startActivity(intentCall);
                    }
                }
            }
        });
    }
    private void requestPermission()
    {
        ActivityCompat.requestPermissions(BlindPersonDetailsActivity.this,new String[]{Manifest.permission.CALL_PHONE},1);
    }
    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Your GPS seems to be disabled, you want to enable it!!")
                .setCancelable(false)
                .setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    private void getImage()
    {
        storageReference= FirebaseStorage.getInstance().getReference();

        final StorageReference image = storageReference.child(firebaseUser.getUid()).child("blind.jpg");

        image.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri).into(blindImageView);
            }
        });
    }
}