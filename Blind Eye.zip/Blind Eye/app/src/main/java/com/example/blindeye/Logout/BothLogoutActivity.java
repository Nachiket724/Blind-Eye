package com.example.blindeye.Logout;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.example.blindeye.R;
import com.example.blindeye.dashBoard.ApplicationDashboard;
import com.example.blindeye.welcomeScreen.SignInOrSignUp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class BothLogoutActivity extends AppCompatActivity {

    private Button logoutFromCareTakerApplication,logoutFromBlindApplication,logoutFromBothDevices;

    private FirebaseUser firebaseUser;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_both_logout);

        logoutFromCareTakerApplication=findViewById(R.id.logoutFromCaretaker);
        logoutFromBlindApplication=findViewById(R.id.logoutFromBlindApplication);
        logoutFromBothDevices=findViewById(R.id.logoutFromBothApplication);

        logoutFromCareTakerApplication.setTranslationX(800);
        logoutFromBlindApplication.setTranslationX(-800);
        logoutFromBothDevices.setTranslationX(800);

        logoutFromCareTakerApplication.animate().translationX(0).alpha(1).setDuration(1000).setStartDelay(700).start();
        logoutFromBlindApplication.animate().translationX(0).alpha(1).setDuration(1000).setStartDelay(700).start();
        logoutFromBothDevices.animate().translationX(0).alpha(1).setDuration(1000).setStartDelay(700).start();

        logoutFromCareTakerApplication.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               logoutFromCareTakerApplicationFunction();
            }
        });

        logoutFromBlindApplication.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutFromBlindApplicationFunction();
            }
        });
        logoutFromBothDevices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutFromBlindApplicationFunction();
                logoutFromCareTakerApplicationFunction();
            }
        });
    }
    private void logoutFromCareTakerApplicationFunction()
    {
        FirebaseAuth.getInstance().signOut();
        Intent intent=new Intent(getApplicationContext(), SignInOrSignUp.class);
        startActivity(intent);
        finish();
    }
    private void logoutFromBlindApplicationFunction()
    {
        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        databaseReference= FirebaseDatabase.getInstance().getReference("MyUsers");
        databaseReference.child(firebaseUser.getUid()).child("Blind").child("logout").setValue(true);
        Toast.makeText(this, "Now manually logout from Blind Application", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        Intent intent=new Intent(getApplicationContext(), ApplicationDashboard.class);
        startActivity(intent);
        finish();
    }
}