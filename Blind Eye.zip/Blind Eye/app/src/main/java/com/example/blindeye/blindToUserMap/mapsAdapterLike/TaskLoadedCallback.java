package com.example.blindeye.blindToUserMap.mapsAdapterLike;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}
