package com.example.blindeye.loginSignup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatRadioButton;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.agrawalsuneet.dotsloader.loaders.CircularDotsLoader;
import com.blogspot.atifsoftwares.animatoolib.Animatoo;

import com.example.blindeye.R;
import com.example.blindeye.dashBoard.ApplicationDashboard;
import com.example.blindeye.loginSignup.Adapters.RegisterAdapter;
import com.example.blindeye.welcomeScreen.SignInOrSignUp;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Register extends AppCompatActivity implements View.OnKeyListener{

    EditText mFullName,mEmail,mPassword,mPhone;
    Button mRegisterBtn, mFinalRegisterBtn;
    FirebaseAuth fAuth;
    CircularDotsLoader progressBar, progressBar2;
    TextView registerBirthDate, photoUserName;
    ImageView profileImage;
    Uri imageUri;
    String currentPhotoPath;

    ConstraintLayout constraintLayoutEmail, constraintLayoutOther,constraintLayoutRadioGroups;

    private int mDate,mMonth,mYear;

    AppCompatRadioButton radio_male,radio_female;
    RadioGroup radioGroup;
    RadioButton radioButton;

    FirebaseUser firebaseUser;
    DatabaseReference databaseReference;
    StorageReference storageReference;

    String gender,name,emailID,bDate;
    Intent intent;

    ImageView logoRegister,backgroundImage;
    //TextView registerText;
    CardView cardViewAllStuffRegister;
    ConstraintLayout regsiterUploadImageClick;

    private final String regexEmail="^[A-Za-z0-9+_.-]+@(.+)$";
    private final String regexPhoneNo="^[6-9]\\d{9}$";
    private final String regexName="^[A-Za-z][a-zA-Z ]+$";
    private final String regexPassword="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";

    boolean toCloseOrNot=true;

    @Override
    public boolean onKey(View view, int i, KeyEvent keyEvent) {

        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_register_new);

        LocationManager manager = (LocationManager) getSystemService( Context.LOCATION_SERVICE );

        if ( !manager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
            buildAlertMessageNoGps();
        }

        if(ContextCompat.checkSelfPermission(Register.this,
                Manifest.permission.CAMERA)+
                ContextCompat.checkSelfPermission(Register.this,
                        Manifest.permission.ACCESS_FINE_LOCATION)+
                ContextCompat.checkSelfPermission(Register.this,
                        Manifest.permission.ACCESS_COARSE_LOCATION)+
                ContextCompat.checkSelfPermission(Register.this,
                        Manifest.permission.READ_EXTERNAL_STORAGE)+
                ContextCompat.checkSelfPermission(Register.this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)+
                ContextCompat.checkSelfPermission(Register.this,
                        Manifest.permission.CALL_PHONE)+
                ContextCompat.checkSelfPermission(Register.this,
                        Manifest.permission.INTERNET)+
                ContextCompat.checkSelfPermission(Register.this,
                        Manifest.permission.RECORD_AUDIO)!=
                PackageManager.PERMISSION_GRANTED)
        {
            Intent intent=new Intent();
            intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            Uri uri=Uri.fromParts("package",getPackageName(),null);
            intent.setData(uri);
            startActivity(intent);
        }

        mFullName=findViewById(R.id.editTextUserNameRegisterNew);
        mEmail=findViewById(R.id.editTextEmailRegisterNew);
        mPassword=findViewById(R.id.editTextPasswordRegisterNew);
        mPhone=findViewById(R.id.editTextPhoneNumber);
        mRegisterBtn=findViewById(R.id.buttonRegisterNew);
        profileImage=findViewById(R.id.blindImageView);
        constraintLayoutEmail=findViewById(R.id.constraintLayoutEmail);
        registerBirthDate=findViewById(R.id.registerBirthDate);

        constraintLayoutEmail.setVisibility(View.VISIBLE);

        fAuth=FirebaseAuth.getInstance();
        
        progressBar=findViewById(R.id.progressBarRegisterNew);
        radio_male=findViewById(R.id.maleRadioBlindNew);
        radio_female=findViewById(R.id.femaleRadioBlindNew);
        constraintLayoutOther=findViewById(R.id.constraintLayoutOther);
        progressBar2=findViewById(R.id.progressBarLoginNew);
        mFinalRegisterBtn=findViewById(R.id.registerNewDetails);
        photoUserName=findViewById(R.id.photoUserName);
        radioGroup=findViewById(R.id.radioGroupBlindNew);
        constraintLayoutRadioGroups=findViewById(R.id.constraintLayoutRadioGroupsBlind);

        logoRegister=findViewById(R.id.logoRegister);
        //registerText=findViewById(R.id.registerText);
        backgroundImage=findViewById(R.id.backgroundImage);
        cardViewAllStuffRegister=findViewById(R.id.cardViewAllStuffRegister);
        regsiterUploadImageClick=findViewById(R.id.regsiterUploadImageClick);

        mEmail.setOnKeyListener(this);
        mPassword.setOnKeyListener(this);

        logoRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickedBackground();
            }
        });

//        registerText.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                clickedBackground();
//            }
//        });

        backgroundImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickedBackground();
            }
        });

        cardViewAllStuffRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickedBackground();
            }
        });

        regsiterUploadImageClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickedBackground();
            }
        });

        if(fAuth.getCurrentUser()!=null)
        {
            startActivity(new Intent(getApplicationContext(), ApplicationDashboard.class));
            finish();
        }

        mFullName.setTranslationX(800);
        mEmail.setTranslationX(800);
        mPassword.setTranslationX(800);
        mRegisterBtn.setTranslationX(800);

        mPhone.setTranslationX(800);
        registerBirthDate.setTranslationX(800);
        constraintLayoutRadioGroups.setTranslationX(800);
        mFinalRegisterBtn.setTranslationX(800);

        mFullName.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        mEmail.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(700).start();
        mPassword.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(900).start();
        mRegisterBtn.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(1100).start();

        CircularDotsLoader loader = new CircularDotsLoader(this);
        loader.setBigCircleRadius(80);
        loader.setRadius(24);
        loader.setAnimDur(300);
        loader.setShowRunningShadow(true);

        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder=new AlertDialog.Builder(Register.this);
                builder.setTitle("Add Profile Photo!!");
                builder.setPositiveButton("Camera", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        askCameraPermission();
                    }
                });
                builder.setNegativeButton("Gallery", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent openGalleryIntent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        startActivityForResult(openGalleryIntent,1000);
                    }
                });
                AlertDialog alertDialog=builder.create();
                alertDialog.show();
            }
        });



        mRegisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String email=mEmail.getText().toString().trim();
                String password=mPassword.getText().toString().trim();
                name=mFullName.getText().toString();

                if(TextUtils.isEmpty(name))
                {
                    mFullName.setError("Name is Required!");
                    return;
                }
                if(TextUtils.isEmpty(email))
                {
                    mEmail.setError("Email is Required!");
                    return;
                }
                if(TextUtils.isEmpty(password))
                {
                    mPassword.setError("Password is Required!");
                    return;
                }

                Pattern patternEmail = Pattern.compile(regexEmail);
                Matcher matcherEmail=patternEmail.matcher(email);

                Pattern patternName = Pattern.compile(regexName);
                Matcher matcherName=patternName.matcher(name);

                Pattern patternPass=Pattern.compile(regexPassword);
                Matcher matcherPass=patternPass.matcher(password);

                if(!matcherName.matches())
                {
                    mFullName.setError("Name must contain more than one Alphabets !");
                    return;
                }
                if(!matcherEmail.matches())
                {
                    mEmail.setError("Enter Valid Email-ID");
                    return;
                }

                if(password.length()<7)
                {
                    mPassword.setError("Password must be more than 7 Characters!");
                    return;
                }

                if(!matcherPass.matches())
                {
                    mPassword.setError("Password must contain Atleast One Digit, One Lowercase Letter" +
                            ", one Uppercase Letter, one Special Character and no White Space.");
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);

                fAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                        {
                            toCloseOrNot=false;

                            firebaseUser= FirebaseAuth.getInstance().getCurrentUser();

                            databaseReference= FirebaseDatabase.getInstance().getReference("MyUsers");

                            storageReference=FirebaseStorage.getInstance().getReference();

                            emailID=mEmail.getText().toString();

                            constraintLayoutEmail.setVisibility(View.GONE);
                            photoUserName.setText(name);

                            constraintLayoutOther.setVisibility(View.VISIBLE);

                            mPhone.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(400).start();
                            registerBirthDate.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(600).start();
                            constraintLayoutRadioGroups.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(800).start();
                            mFinalRegisterBtn.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(1000).start();
                        }
                        else
                        {
                            Toast.makeText(Register.this, "Error!! "+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });
            }
        });

        mFinalRegisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int radioId=radioGroup.getCheckedRadioButtonId();

                radioButton=findViewById(radioId);
                gender=radioButton.getText().toString();
                String phone=mPhone.getText().toString();
                bDate=registerBirthDate.getText().toString();

                Pattern patternPhone=Pattern.compile(regexPhoneNo);
                Matcher matcherPhone=patternPhone.matcher(phone);

                if(!matcherPhone.matches())
                {
                    mPhone.setError("Enter Valid 10 Digit Mobile Number");
                    return;
                }

                if(bDate==null || bDate.isEmpty() || TextUtils.isEmpty(bDate))
                {
                    registerBirthDate.setError("Select Birthdate");
                    return;
                }

                if(imageUri==null)
                {
                    AlertDialog.Builder builder=new AlertDialog.Builder(Register.this);
                    builder.setTitle("Upload Profile Photo!!");
                    builder.setPositiveButton("Okay",null);
                    AlertDialog alertDialog=builder.create();
                    alertDialog.show();
                    return;
                }
                progressBar2.setVisibility(View.VISIBLE);

                RegisterAdapter registerAdapter=new RegisterAdapter(name,emailID,phone,firebaseUser.getUid(),bDate,gender);
                databaseReference.child(firebaseUser.getUid().toString()).setValue(registerAdapter);

                uploadImageToFirebase(imageUri );

                intent=new Intent(getApplicationContext(),BlindRegistrationPart.class);
                startActivity(intent);
                Animatoo.animateSwipeLeft(Register.this);
                finish();
            }
        });

        registerBirthDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar calendar = Calendar.getInstance();

                mDate=calendar.get(Calendar.DATE);
                mMonth=calendar.get(Calendar.MONTH);
                mYear=calendar.get(Calendar.YEAR);

                DatePickerDialog datePickerDialog=new DatePickerDialog(Register.this, android.R.style.Theme_DeviceDefault_Dialog, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int date) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.set(year, month, date);
                        SimpleDateFormat format = new SimpleDateFormat("dd MMMM yyyy");
                        String dateString = format.format(calendar.getTime());
                        registerBirthDate.setText(dateString);
                    }
                },mYear,mMonth,mDate);
                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis()-1000);
                datePickerDialog.show();


            }
        });
    }

    private void askCameraPermission() {
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},101);
        }
        else
        {
            dispatchTakePictureIntent();
        }
    }

    private void uploadImageToFirebase(Uri imageUri ) {

        StorageReference fileRef=storageReference.child(firebaseUser.getUid()).child("caretaker.jpg");
        fileRef.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(Register.this, "Failed!!", Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==1000)
        {
            if(resultCode== Activity.RESULT_OK)
            {
                imageUri = data.getData();
                profileImage.setImageURI(imageUri);
            }
        }
        else if(requestCode==102)
        {
            if(resultCode==Activity.RESULT_OK)
            {
                File f=new File(currentPhotoPath);
                profileImage.setImageURI(Uri.fromFile(f));
            }
        }
    }

    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Your GPS seems to be disabled, you have to enable it!!")
                .setCancelable(false)
                .setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    public void onRadioButtonClicked(View view)
    {
        boolean isSelected=((AppCompatRadioButton)view).isChecked();

        switch (view.getId())
        {
            case R.id.maleRadioBlindNew:

                if(isSelected) {
                    radio_male.setTextColor(Color.WHITE);
                    radio_female.setTextColor(Color.parseColor("#306e70"));
                }
                break;
            case R.id.femaleRadioBlindNew:
                if(isSelected) {
                    radio_male.setTextColor(Color.parseColor("#306e70"));
                    radio_female.setTextColor(Color.WHITE);
                }
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode==101)
        {
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
            {
                dispatchTakePictureIntent();
            }
            else
            {
                Toast.makeText(this, "Camera Permission is Required!!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String imageFileName = "caretaker";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                imageUri = FileProvider.getUriForFile(this,
                        "com.example.android.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                startActivityForResult(takePictureIntent, 102);
            }
        }
    }

    @Override
    public void onBackPressed() {

        if(toCloseOrNot) {

            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setMessage("Proceed towards Home Page?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent=new Intent(getApplicationContext(), SignInOrSignUp.class);
                            startActivity(intent);
                            Animatoo.animateSwipeRight(Register.this);
                            finish();
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();
                        }
                    });
            AlertDialog alertDialog=builder.create();
            alertDialog.show();
        }
        else
        {
            AlertDialog.Builder builder=new AlertDialog.Builder(this);

            builder.setMessage("You cannot exit the Application, untill you complete the Registration Part !! ")
                    .setCancelable(false)
                    .setPositiveButton("Okay", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.cancel();
                        }
                    });
            AlertDialog alertDialog=builder.create();
            alertDialog.show();
        }
    }

    private void clickedBackground()
    {
        try {
            InputMethodManager inputMethodManager=(InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),0);
        }catch (Exception e)
        {

        }

    }
}