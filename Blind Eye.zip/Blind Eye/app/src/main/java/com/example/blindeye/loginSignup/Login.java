package com.example.blindeye.loginSignup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.agrawalsuneet.dotsloader.loaders.CircularDotsLoader;

import com.example.blindeye.R;
import com.example.blindeye.dashBoard.ApplicationDashboard;
import com.example.blindeye.welcomeScreen.SignInOrSignUp;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Login extends AppCompatActivity {

    EditText mEmail,mPassword;
    TextView forgotPassword;
    Button mLoginButton;
    CircularDotsLoader progressBar;
    FirebaseAuth fAuth;
    ConstraintLayout constraintLayoutLogin;

    TextView registerText,loginTextView;
    CardView cardViewLogin;
    ImageView logoRegister;


    static final int REQUEST_CODE=123;

    private final String regexEmail="^[A-Za-z0-9+_.-]+@(.+)$";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login_new);

        final LocationManager manager = (LocationManager) getSystemService( Context.LOCATION_SERVICE );

        if ( !manager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
            buildAlertMessageNoGps();
        }

        if(ContextCompat.checkSelfPermission(Login.this,
                Manifest.permission.CAMERA)+
                ContextCompat.checkSelfPermission(Login.this,
                        Manifest.permission.ACCESS_FINE_LOCATION)+
                ContextCompat.checkSelfPermission(Login.this,
                        Manifest.permission.ACCESS_COARSE_LOCATION)+
                ContextCompat.checkSelfPermission(Login.this,
                        Manifest.permission.READ_EXTERNAL_STORAGE)+
                ContextCompat.checkSelfPermission(Login.this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)+
                ContextCompat.checkSelfPermission(Login.this,
                        Manifest.permission.CALL_PHONE)+
                ContextCompat.checkSelfPermission(Login.this,
                        Manifest.permission.INTERNET)+
                ContextCompat.checkSelfPermission(Login.this,
                        Manifest.permission.RECORD_AUDIO)!=
                PackageManager.PERMISSION_GRANTED)
        {
            Intent intent=new Intent();
            intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            Uri uri=Uri.fromParts("package",getPackageName(),null);
            intent.setData(uri);
            startActivity(intent);
        }

        mEmail=findViewById(R.id.editTextLoginEmailNew);
        mPassword=findViewById(R.id.editTextLoginPasswordNew);
        progressBar=findViewById(R.id.progressBarLoginNew);
        fAuth=FirebaseAuth.getInstance();
        mLoginButton=findViewById(R.id.buttonLoginNew);
        forgotPassword=findViewById(R.id.forgotPasswordNew);
        constraintLayoutLogin=findViewById(R.id.constraintlayoutLogin);

        registerText=findViewById(R.id.registerText);
        loginTextView=findViewById(R.id.loginTextView);
        cardViewLogin=findViewById(R.id.loginCardView);
        logoRegister=findViewById(R.id.logoRegister);

        registerText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickedBackground();
            }
        });

        loginTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickedBackground();
            }
        });
        cardViewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickedBackground();
            }
        });

        logoRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickedBackground();
            }
        });

        constraintLayoutLogin.setVisibility(View.VISIBLE);

        mEmail.setTranslationX(800);
        mPassword.setTranslationX(800);
        mLoginButton.setTranslationX(800);
        forgotPassword.setTranslationX(800);

        mEmail.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        mPassword.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(700).start();
        forgotPassword.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(900).start();
        mLoginButton.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(1100).start();

        CircularDotsLoader loader = new CircularDotsLoader(this);
        loader.setBigCircleRadius(80);
        loader.setRadius(24);
        loader.setAnimDur(300);
        loader.setShowRunningShadow(true);

        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final EditText resetMail=new EditText(view.getContext());

                AlertDialog.Builder passwordResetDialog=new AlertDialog.Builder(view.getContext());
                passwordResetDialog.setTitle("Reset Password!!");
                passwordResetDialog.setMessage("Enter your Email to Received the Reset Link.");
                passwordResetDialog.setCancelable(false);
                passwordResetDialog.setView(resetMail);

                passwordResetDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        String mail=resetMail.getText().toString().trim();
                        fAuth.sendPasswordResetEmail(mail).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(Login.this, "Reset Link Has Been Sent To Your Email!", Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(Login.this, "Error ! "+e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });

                passwordResetDialog.setNegativeButton("Cancel",null);
                passwordResetDialog.create().show();
            }
        });

        mLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email=mEmail.getText().toString().trim();
                String password=mPassword.getText().toString().trim();

                if(TextUtils.isEmpty(email))
                {
                    mEmail.setError("Email is Required!");
                    return;
                }
                if(TextUtils.isEmpty(password))
                {
                    mPassword.setError("Password is Required!");
                    return;
                }

                Pattern patternEmail = Pattern.compile(regexEmail);
                Matcher matcherEmail=patternEmail.matcher(email);

                if(!matcherEmail.matches())
                {
                    mEmail.setError("Enter Valid Email-ID");
                    return;
                }

                if(password.length()<7)
                {
                    mPassword.setError("Password must be more than 7 Characters!");
                    return;
                }


                progressBar.setVisibility(View.VISIBLE);

                fAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {
                            startActivity(new Intent(getApplicationContext(), ApplicationDashboard.class));
                            finish();
                        }
                        else
                        {
                            Toast.makeText(Login.this, "Error!! "+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });
            }
        });
    }
    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Your GPS seems to be disabled, you want to enable it!!")
                .setCancelable(false)
                .setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public void onBackPressed() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setMessage("Proceed towards Home Page?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent=new Intent(getApplicationContext(), SignInOrSignUp.class);
                        startActivity(intent);
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();
    }

    private void clickedBackground()
    {
        try {
            InputMethodManager inputMethodManager=(InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),0);
        }catch (Exception e)
        {

        }

    }
}