package com.example.blindeye.dashBoard.Adapters;

import android.location.Location;

public class LocationAdapters {

    Location location;

    public LocationAdapters(Location location) {
        this.location = location;
    }

    public LocationAdapters() {
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "LocationAdapters{" +
                "location=" + location +
                '}';
    }
}
