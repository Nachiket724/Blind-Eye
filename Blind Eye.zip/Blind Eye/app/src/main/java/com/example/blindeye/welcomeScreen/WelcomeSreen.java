package com.example.blindeye.welcomeScreen;


import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.blindeye.R;
import com.example.blindeye.loginSignup.Register;


public class WelcomeSreen extends AppCompatActivity {

    private static int SPLASH_SCREEN=4000;

    Animation topAnim,bottomAnim;
    ImageView mainAppImageView;
    TextView mainAppName,slogan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_welcome_sreen);

        Context context;
        topAnim=AnimationUtils.loadAnimation(this,R.anim.top_animation_welcome);
        bottomAnim=AnimationUtils.loadAnimation(this,R.anim.bottom_animation);

        mainAppImageView=findViewById(R.id.mainLogo);
        mainAppName=findViewById(R.id.mainAppName);
        slogan=findViewById(R.id.sloganBlind);

        mainAppImageView.setAnimation(topAnim);
        mainAppName.setAnimation(bottomAnim);
        slogan.setAnimation(bottomAnim);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if(ContextCompat.checkSelfPermission(WelcomeSreen.this,
                        Manifest.permission.CAMERA)+
                        ContextCompat.checkSelfPermission(WelcomeSreen.this,
                                Manifest.permission.ACCESS_FINE_LOCATION)+
                        ContextCompat.checkSelfPermission(WelcomeSreen.this,
                                Manifest.permission.ACCESS_COARSE_LOCATION)+
                        ContextCompat.checkSelfPermission(WelcomeSreen.this,
                                Manifest.permission.READ_EXTERNAL_STORAGE)+
                        ContextCompat.checkSelfPermission(WelcomeSreen.this,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE)+
                        ContextCompat.checkSelfPermission(WelcomeSreen.this,
                                Manifest.permission.CALL_PHONE)+
                        ContextCompat.checkSelfPermission(WelcomeSreen.this,
                                Manifest.permission.INTERNET)==
                        PackageManager.PERMISSION_GRANTED) {
                    Intent intent = new Intent(getApplicationContext(), SignInOrSignUp.class);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Intent intent = new Intent(getApplicationContext(), PermissionActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        },SPLASH_SCREEN);
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setMessage("Are you sure, you want to Exit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                        System.exit(0);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();
    }
}